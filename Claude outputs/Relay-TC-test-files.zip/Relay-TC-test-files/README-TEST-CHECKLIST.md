# Relay TC test files

All data is fictional (482 Maple Ridge Dr, Springfield, IL; buyers Riley and Morgan Thompson;
sellers Jordan and Casey Whitfield). Email addresses use example.com, so change the agent, client,
lender and title emails to YOUR OWN test inboxes before you use them, or Relay will try to email
people who don't exist. The agent email in the documents is dana.brooks@example.com.

Do the flow in this order, using a fresh TC test account and a second email for the agent.

1. **Listing** (01-listing): create the listing from listing-agreement-clean.pdf and check the
   address, price, list date and expiration extract. Then try listing-agreement-scanned.pdf
   (image-only: expect extraction to struggle, and that you can fill fields by hand).
   Upload the disclosure, photo and docx as listing documents. Assign the agent and check the invite.
2. **Offers** (02-offers): add offer 1, 2 (counteroffer) and 3 (addendum), plus offer-4-photo.png
   as an image. Compare versions.
3. **Convert to a transaction** (03-transaction-contracts): upload purchase-contract-full.pdf and
   check price, dates, parties and key dates. Then purchase-contract-oddities.pdf (relative dates,
   a blank closing date) and the scanned version. Run duplicate-address-tests.txt.
4. **Documents** (04-transaction-documents): upload one of every type as the TC, then as the agent.
5. **Refusals** (05-negative-uploads): each file should be rejected with a clear message.
6. **E-sign** (06-esign): send signing-doc.pdf to two signers (your test emails), sign, confirm
   the signed copy.
7. **Deal import** (07-deal-import-csv): see HOW-TO.txt in that folder.
8. **Contacts** (08-contacts-csv): see HOW-TO.txt.
9. **Invoices** (09-invoices): see HOW-TO.txt. Also try sending an email with attachments to a
   listing's inbound address (use files from 04 plus blocked.exe).
10. **Agent view**: sign in as the agent, check the notice shows once and then clears, add a
    contact, send a general message and a deal message.
